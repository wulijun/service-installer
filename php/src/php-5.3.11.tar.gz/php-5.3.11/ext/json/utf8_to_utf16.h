/* utf8_to_utf16.h */

extern int utf8_to_utf16(unsigned short w[], char p[], int length);
