
#ifndef _GDFONTA_H_
#define _GDFONTA_H_ 1

/*
	This is a header file for gd font, generated using
	bdftogd version 0.51 by Jan Pazdziora, adelton@fi.muni.cz
	from bdf font
	-Adobe-Courier-Bold-R-Normal--14-100-100-100-M-90-ISO8859-1
	at Sun Jul 19 12:41:12 1998.
	The original bdf was holding following copyright:
	"Copyright (c) 1984, 1987 Adobe Systems Incorporated. All Rights Reserved. Copyright (c) 1988, 1991 Digital Equipment Corporation. All Rights Reserved."
 */


#include "gd.h"

extern gdFontPtr gdFontAdobe;

#endif

